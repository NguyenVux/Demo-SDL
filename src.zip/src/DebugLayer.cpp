#include "pch.h"
#include "DebugLayer.h"

void DebugLayer::PreFrame() {
}
void DebugLayer::Update() {
}
void DebugLayer::Render() {
}
void DebugLayer::PostFrame() {
}
DebugLayer::~DebugLayer() {}
